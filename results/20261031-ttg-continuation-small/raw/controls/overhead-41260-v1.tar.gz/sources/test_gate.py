"""Synthetic release fixtures only; never write the real main authorization."""
import copy
import json
from pathlib import Path
import tempfile
import unittest
from evidence import sha256
from gate import CONFIGURATIONS, OWN, validate, revalidate, payload_errors


class SyntheticRelease:
    def __init__(self, root):
        self.root = root
        self.data = {}
        self.source = root / 'synthetic-execution.py'
        self.source.write_text('# synthetic, never executed\n')
        for name in ('runtime', 'overlay', 'suite'):
            folder = root / (name + '-tree')
            folder.mkdir()
            (folder / 'source.txt').write_text('synthetic ' + name)
            self.data[name] = dict(root=str(folder), files={'source.txt':sha256(folder/'source.txt')})
        self.data['runtime_tests'] = dict(passed=True)
        self.data['runtime'].update(kind='runtime_snapshot',immutable=True,commit='a'*40,
            continuation_dispatch='runtime_hooks')
        (root/'boundary.patch').write_text('synthetic, not a runtime patch\n')
        self.data['overlay'].update(kind='experiment_overlay',same_for_all_configurations=True)
        self.data['inventory'] = dict(cases=[dict(case_id='synthetic-case',implemented=True,
            required_checks=['native','oracle','fresh_session','restart'])])
        self.data['suite'].update(kind='benchmark_suite_snapshot',final=True)
        self.data['selection'] = dict(accepted=True,case_ids=['synthetic-case'])
        self.data['plan'] = dict(case_ids=['synthetic-case'],configurations=[
            dict(id=i,policy=p,executor=e,effective_config_sha256=('%064x'%(n+1)))
            for n,(i,p,e) in enumerate(CONFIGURATIONS)],
            measured_repeats=3,excluded_warmups=1,quiet_window_confirmed=True,
            startup_ipc_accounting='included_and_separate',cache_regime='synthetic-explicit',
            model_regime='synthetic-untrained',seeds=[42])
        self.data['instrument'] = dict(passed=True,sources={
            str(OWN/name):sha256(OWN/name) for name in
            ('gate.py','evidence.py','intervals.py','observation.py','protocol.py','worker_clock.py')})
        self.data['instrument']['sources'][str(self.source)] = sha256(self.source)
        for key in ('protocol_validation','independent_sql_reconciliation','overhead_review','concurrency_review'):
            self.data[key] = dict(accepted=True)
        self.data['correctness'] = dict(passed=True,cases=[])
        self.evidences = []
        for config in self.data['plan']['configurations']:
            folder = root / config['id']; folder.mkdir()
            evidence = dict(passed=True,case_id='synthetic-case',seed=42,config_id=config['id'],
                checks=dict(native=True,oracle=True,fresh_session=True,restart=True),
                effective_config_sha256=config['effective_config_sha256'],
                **{key:'b'*64 for key in ('fixture_sha256','actions_sha256','output_sha256','state_sha256','oracle_sha256')})
            (folder/'server-1.events.jsonl').write_text('{"errors":[],"plan":{"payload_error":null}}\n')
            self.evidences.append((folder,evidence))
            self.data['correctness']['cases'].append(copy.deepcopy(evidence))
        self.issue()

    def write(self, name):
        path = self.root/(name+'.json')
        path.write_text(json.dumps(self.data[name],sort_keys=True,indent=2)+'\n')
        return self.ref(path)

    def ref(self,path): return dict(path=str(path),sha256=sha256(path))

    def seal_case(self,index):
        folder,evidence = self.evidences[index]
        path = folder/'evidence.json'; path.write_text(json.dumps(evidence))
        files={p.name:sha256(p) for p in folder.iterdir() if p.is_file() and p.name!='artifacts.json'}
        (folder/'artifacts.json').write_text(json.dumps(dict(passed=True,files=files)))
        self.data['correctness']['cases'][index]['evidence']=self.ref(path)

    def issue(self):
        self.data['runtime']['test_evidence']=self.write('runtime_tests')
        runtime=self.write('runtime')
        self.data['overlay'].update(base_runtime_manifest_sha256=runtime['sha256'],patch=self.ref(self.root/'boundary.patch'))
        overlay=self.write('overlay')
        self.data['suite']['case_inventory']=self.write('inventory')
        suite=self.write('suite')
        self.data['selection']['case_inventory_sha256']=self.data['suite']['case_inventory']['sha256']
        selection=self.write('selection')
        plan=self.write('plan')
        for key in ('protocol_validation','independent_sql_reconciliation','overhead_review','concurrency_review'):
            self.data['instrument'][key]=self.write(key)
        self.data['instrument'].update(runtime_manifest_sha256=runtime['sha256'],overlay_manifest_sha256=overlay['sha256'])
        instrument=self.write('instrument')
        for i in range(len(self.evidences)): self.seal_case(i)
        self.data['correctness'].update(runtime_manifest_sha256=runtime['sha256'],suite_manifest_sha256=suite['sha256'])
        correctness=self.write('correctness')
        refs=dict(runtime=runtime,overlay=overlay,suite=suite,selection=selection,correctness=correctness,
            instrument=instrument,plan=plan)
        self.data['main_review']=dict(accepted=True,artifact_sha256={k:v['sha256'] for k,v in refs.items()})
        refs['main_review']=self.write('main_review')
        self.data['authorization']=dict(schema_version=1,approved=True,approved_by='main',artifacts=refs)
        self.write('authorization')
        self.authorization=self.root/'authorization.json'


class GateTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(dir=OWN,prefix='synthetic-gate-')
        self.release=SyntheticRelease(Path(self.temp.name))

    def tearDown(self): self.temp.cleanup()

    def check(self): return validate(self.release.authorization)

    def reject_after_issue(self,pattern):
        self.release.issue()
        with self.assertRaisesRegex(ValueError,pattern): self.check()

    def test_complete_synthetic_release_passes_and_revalidates(self): revalidate(self.check())

    def test_missing_authorization_fails(self):
        with self.assertRaisesRegex(ValueError,'authorization absent'): validate(self.release.root/'absent.json')

    def test_non_main_approval_fails(self):
        self.release.data['authorization']['approved_by']='worker'
        self.release.write('authorization')
        with self.assertRaisesRegex(ValueError,'Main approval'): self.check()

    def test_mutable_runtime_fails(self):
        self.release.data['runtime']['immutable']=False
        self.reject_after_issue('immutable runtime')

    def test_untested_runtime_fails(self):
        self.release.data['runtime_tests']['passed']=False
        self.reject_after_issue('not passed review')

    def test_source_mutation_fails(self):
        (self.release.root/'runtime-tree/source.txt').write_text('mutated')
        with self.assertRaisesRegex(ValueError,'Source mutation'): self.check()

    def test_unlisted_source_fails(self):
        (self.release.root/'suite-tree/extra.jac').write_text('extra source')
        with self.assertRaisesRegex(ValueError,'unlisted files'): self.check()

    def test_stale_overlay_base_fails(self):
        self.release.data['overlay']['base_runtime_manifest_sha256']='0'*64
        overlay=self.release.write('overlay')
        auth=self.release.data['authorization']; auth['artifacts']['overlay']=overlay
        self.release.data['main_review']['artifact_sha256']['overlay']=overlay['sha256']
        auth['artifacts']['main_review']=self.release.write('main_review')
        self.release.write('authorization')
        with self.assertRaisesRegex(ValueError,'Overlay base mismatch'): self.check()

    def test_six_configuration_coverage_is_required(self):
        self.release.data['plan']['configurations'].pop()
        self.reject_after_issue('six required configurations')

    def test_incomplete_case_matrix_fails(self):
        self.release.data['correctness']['cases'].pop()
        # issue() updates only existing rows, so write the shorter index after issuing.
        self.release.evidences.pop()
        self.reject_after_issue('correctness matrix')

    def test_required_check_failures(self):
        for check in ('native','oracle','fresh_session','restart'):
            with self.subTest(check=check):
                self.release.data['correctness']['cases'][0]['checks'][check]=False
                self.reject_after_issue('Incomplete native')
                self.release.data['correctness']['cases'][0]['checks'][check]=True

    def test_mandatory_checks_cannot_be_removed_from_inventory(self):
        self.release.data['inventory']['cases'][0]['required_checks'].remove('restart')
        self.reject_after_issue('Mandatory correctness')

    def test_non_equivalent_fixture_actions_outputs_state_oracle_fail(self):
        for field in ('fixture_sha256','actions_sha256','output_sha256','state_sha256','oracle_sha256'):
            with self.subTest(field=field):
                self.release.data['correctness']['cases'][-1][field]='c'*64
                self.reject_after_issue('Non-equivalent')
                self.release.data['correctness']['cases'][-1][field]='b'*64

    def test_top_level_empty_errors_does_not_hide_nested_payload_failure(self):
        self.release.evidences[0][1].update(errors=[],plans=[dict(payload_error='child SQL failed')])
        self.reject_after_issue('Nested plan payload_error')

    def test_late_raw_payload_error_fails_even_when_summary_is_clean(self):
        folder,_=self.release.evidences[0]
        (folder/'server-1.events.jsonl').write_text('{"errors":[],"plans":[{"status":"payload_error"}]}\n')
        self.reject_after_issue('Raw plan payload_error')

    def test_startup_and_ipc_cannot_be_excluded(self):
        self.release.data['plan']['startup_ipc_accounting']='excluded'
        self.reject_after_issue('startup/IPC')

    def test_three_primary_repetitions_required(self):
        self.release.data['plan']['measured_repeats']=2
        self.reject_after_issue('Three measured trials')

    def test_final_quiet_window_required(self):
        self.release.data['plan']['quiet_window_confirmed']=False
        self.reject_after_issue('quiet window')

    def test_live_artifact_mutation_stops_experiment(self):
        release=self.check()
        folder,_=self.release.evidences[0]
        (folder/'server-1.events.jsonl').write_text('{}\n')
        with self.assertRaisesRegex(ValueError,'artifact changed'): revalidate(release)

    def test_live_analysis_mutation_stops_experiment(self):
        release=self.check(); self.release.source.write_text('mutated analysis')
        with self.assertRaisesRegex(ValueError,'source changed'): revalidate(release)

    def test_recursive_payload_error_detection_is_narrow(self):
        self.assertEqual(payload_errors({'plan':{'payload_error':None},'message':'payload_error'}),[])
        self.assertEqual(len(payload_errors({'plans':[{'payload_error':{'error':'failure'}}]})),1)


if __name__=='__main__': unittest.main()
