"""Synthetic/unit evidence only: no sockets, PostgreSQL or benchmark execution."""
import gzip
import json
from pathlib import Path
import struct
import tempfile
import threading
import time
import unittest
from evidence import sha256, verify_case, load_jsonl
from intervals import concurrency, union_ns, executor_evidence
from observation import Observer, WorkerHandle
from protocol import backend_pid, packet_diagnostics, response_diagnostics
from worker_clock import WorkerClock

OWN = Path(__file__).resolve().parent


def call(role, begin, end, backend, process=100, request='r1', generation=1):
    return dict(role=role, send_ns=begin, ready_ns=end, backend_pid=backend,
        client_process_pid=process, origin_request_id=request, trial_id='trial1',
        server_generation=generation, clock_domain='synthetic-clock')


class ProtocolTests(unittest.TestCase):
    def test_backend_key_exposes_only_actual_pid(self):
        self.assertEqual(backend_pid(struct.pack('!II', 12345, 0xDEADBEEF)), 12345)
        with self.assertRaises(ValueError): backend_pid(b'bad')

    def test_one_packet_many_statements_and_rows_are_distinct_counts(self):
        packet = b''.join(k.encode()+struct.pack('!I',4) for k in 'PBDES')
        self.assertEqual(packet_diagnostics(packet)['sync_messages'], 1)
        counters = response_diagnostics([('D',b'row1'),('D',b'row2'),('C',b'SELECT 2\0'),('C',b'COMMIT\0'),('Z',b'I')])
        self.assertEqual((counters['command_complete'], counters['data_rows'], counters['ready_messages']), (2,2,1))

    def test_expected_error_drains_to_ready(self):
        c = response_diagnostics([('E',b'error'),('Z',b'I')])
        self.assertEqual((c['error_messages'],c['ready_messages']), (1,1))

    def test_reject_truncated_frontend_packet(self):
        with self.assertRaises(ValueError): packet_diagnostics(b'P\0\0\0\x10short')


class IntervalTests(unittest.TestCase):
    def test_child_pid_without_sql_does_not_prove_process_execution(self):
        x = executor_evidence([call('foreground',0,10,11)], 'process', 100)
        self.assertFalse(x['sql_execution_observed'])

    def test_process_fallback_to_thread_is_rejected(self):
        bg = call('background_prefetch',0,10,22)
        bg['actual_executor'] = 'thread'
        with self.assertRaisesRegex(ValueError,'fell back'):
            executor_evidence([bg], 'process', 100)

    def test_actual_child_sql_requires_backend_and_child_pid(self):
        bg = call('background_prefetch',0,10,22,process=200)
        bg['actual_executor'] = 'process'
        self.assertTrue(executor_evidence([bg], 'process', 100)['sql_execution_observed'])
        bg['backend_pid'] = None
        with self.assertRaisesRegex(ValueError,'backend PID'):
            executor_evidence([bg], 'process', 100)

    def test_actual_distinct_backend_overlap(self):
        x=concurrency([call('foreground',0,10,11),call('background_prefetch',5,15,22)])['requests'][0]
        self.assertEqual((x['protocol_sum_ns'],x['protocol_union_ns'],x['distinct_backend_overlap_ns']), (20,15,5))
        self.assertEqual(x['separate_process_distinct_backend_overlap_ns'],0)

    def test_actual_child_process_overlap(self):
        x=concurrency([call('foreground',0,10,11),call('background_prefetch',5,15,22,process=200)])['requests'][0]
        self.assertEqual(x['separate_process_distinct_backend_overlap_ns'],5)

    def test_same_backend_is_not_concurrent_backend_evidence(self):
        x=concurrency([call('foreground',0,10,11),call('background_prefetch',5,15,11)])['requests'][0]
        self.assertEqual(x['distinct_backend_overlap_ns'],0)
        self.assertEqual(x['same_backend_overlapping_intervals_ns'],5)

    def test_thread_existence_and_disjoint_queries_prove_no_overlap(self):
        x=concurrency([call('foreground',0,4,11),call('background_prefetch',5,15,22)])['requests'][0]
        self.assertEqual(x['distinct_backend_overlap_ns'],0)

    def test_missing_backend_pid_fails(self):
        with self.assertRaises(ValueError): concurrency([call('foreground',0,10,None)])

    def test_generation_does_not_create_false_overlap(self):
        x=concurrency([call('foreground',0,10,11),call('background_prefetch',5,15,22,generation=2)])
        self.assertTrue(all(r['distinct_backend_overlap_ns']==0 for r in x['requests']))

    def test_late_sql_from_previous_request_is_not_lost(self):
        x=concurrency([call('foreground',10,20,11,request='next'),call('background_prefetch',5,15,22,request='old')])
        self.assertEqual(x['cross_request_distinct_backend_overlap_ns'],5)
        self.assertEqual(x['cross_request_pairs'][0]['background_origin'],'old')

    def test_union_not_sum_for_overlapping_workers(self):
        self.assertEqual(union_ns([(0,10),(5,20),(15,30)]),30)
        with self.assertRaises(ValueError): union_ns([(10,0)])


class EvidenceTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(dir=OWN)
        self.root=Path(self.temp.name)
        (self.root/'server-1.calls.jsonl').write_text('{"data_rows":1}\n')
        self.seal()

    def tearDown(self): self.temp.cleanup()

    def seal(self):
        files={str(p.relative_to(self.root)):sha256(p) for p in self.root.rglob('*') if p.is_file() and p.name!='artifacts.json'}
        (self.root/'artifacts.json').write_text(json.dumps(dict(passed=True,files=files)))

    def test_sealed_trace_reads(self): self.assertEqual(len(load_jsonl(self.root,'server-*.calls.jsonl*')),1)

    def test_valid_looking_injected_unsealed_trace_fails(self):
        (self.root/'server-999.calls.jsonl').write_text('{"data_rows":999}\n')
        with self.assertRaisesRegex(ValueError,'not sealed|Unsealed'): load_jsonl(self.root,'server-*.calls.jsonl*')

    def test_raw_and_gzip_duplicate_fails_even_when_both_sealed(self):
        with gzip.open(self.root/'server-1.calls.jsonl.gz','wt') as f:f.write('{"data_rows":1}\n')
        self.seal()
        with self.assertRaisesRegex(ValueError,'Duplicate'): verify_case(self.root)

    def test_corrupt_trace_fails(self):
        (self.root/'server-1.calls.jsonl').write_text('{"data_rows":2}\n')
        with self.assertRaisesRegex(ValueError,'Corrupt'): verify_case(self.root)


class LifecycleClockTests(unittest.TestCase):
    def test_observer_preserves_native_close_and_retains_late_rows(self):
        gate=threading.Event();ready=threading.Event();calls=[];events=[]
        observer=Observer()
        def worker():
            ready.set();gate.wait()
            calls.append(dict(origin_request_id='original',data_rows=1,end_ns=time.perf_counter_ns()))
        thread=threading.Thread(target=worker,daemon=True);thread.start();ready.wait(1)
        observer.register(WorkerHandle('original',thread.is_alive,thread.join))
        observer.natural_close(lambda:events.append('native_close'))
        self.assertEqual(events,['native_close']);self.assertTrue(thread.is_alive());self.assertEqual(calls,[])
        response_end=time.perf_counter_ns();gate.set();observer.drain_after_response(response_end)
        self.assertEqual(calls[0]['data_rows'],1);self.assertGreater(calls[0]['end_ns'],response_end)
        self.assertEqual(observer.events[0]['pending_after'],1)

    def test_direct_counter_has_valid_same_thread_interval(self):
        with WorkerClock('synthetic','r1') as c:
            sum(i*i for i in range(500))
        self.assertGreaterEqual(c.result['thread_cpu_ns'],0)
        self.assertLessEqual(c.result['thread_cpu_ns'],c.result['wall_ns'])

    def test_errors_propagate_and_are_recorded(self):
        c=WorkerClock('synthetic','r1')
        with self.assertRaisesRegex(ValueError,'expected'):
            with c:raise ValueError('expected')
        self.assertEqual(c.result['error_type'],'ValueError')


if __name__=='__main__': unittest.main()
