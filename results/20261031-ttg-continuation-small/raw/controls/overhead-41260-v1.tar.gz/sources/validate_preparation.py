"""Record offline unit controls; no runtime, benchmark or database execution."""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import sys
from evidence import sha256

OWN=Path(__file__).resolve().parent
ROOT=OWN.parent.parent
EVIDENCE=ROOT/'project-notes/measurements/ttg-continuation-performance-20261030'


def sources():
    return {str(p.relative_to(OWN)):sha256(p) for p in sorted(OWN.glob('*.py'))}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--python',default=sys.executable)
    args=parser.parse_args()
    output=args.output.resolve()
    if not output.is_relative_to(EVIDENCE) or output==EVIDENCE:
        raise ValueError('Unit evidence must use a new directory in the owned evidence root')
    output.mkdir(parents=True,exist_ok=False)
    before=sources()
    command=[args.python,'-B','-m','unittest','discover','-s',str(OWN),'-p','test_*.py','-v']
    started=datetime.now(timezone.utc).isoformat()
    result=subprocess.run(command,cwd=ROOT,text=True,capture_output=True)
    after=sources()
    (output/'stdout.txt').write_text(result.stdout)
    (output/'stderr.txt').write_text(result.stderr)
    summary=dict(kind='offline_unit_controls',benchmark_execution=False,database_execution=False,
        started_utc=started,completed_utc=datetime.now(timezone.utc).isoformat(),
        command=command,cwd=str(ROOT),returncode=result.returncode,
        sources_before=before,sources_after=after,
        passed=result.returncode==0 and before==after)
    (output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    files={p.name:sha256(p) for p in output.iterdir() if p.is_file()}
    (output/'artifacts.json').write_text(json.dumps(dict(passed=summary['passed'],files=files),indent=2)+'\n')
    print(json.dumps(dict(output=str(output),passed=summary['passed'],returncode=result.returncode)))
    return 0 if summary['passed'] else 1


if __name__=='__main__': raise SystemExit(main())
