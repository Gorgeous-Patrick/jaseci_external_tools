import csv
import io
import unittest
from reconcile_sql_validation import csv_limit,terminal_scope


class SupplementalTests(unittest.TestCase):
    def test_large_csv_field_and_restore(self):
        previous=csv.field_size_limit()
        with csv_limit():self.assertEqual(next(csv.reader(io.StringIO('"'+'x'*200000+'"\n')))[0],'x'*200000)
        self.assertEqual(csv.field_size_limit(),previous)

    def test_explicit_upper_limit_still_rejects_excess(self):
        with csv_limit(128):
            with self.assertRaises(csv.Error):list(csv.reader(io.StringIO('x'*256+'\n')))

    def test_terminal_unassigned_control_is_proven_and_retained(self):
        worker=dict(parent_client_process_pid=10,reader_workflows=[dict(end_ns=50)])
        call=dict(origin_request_id=None,sql='DISCARD ALL',send_ns=60,ready_ns=70,role='foreground',client_process_pid=10)
        self.assertTrue(terminal_scope([call],worker)['retained_in_all_SQL_counts'])
        call['send_ns']=40
        with self.assertRaisesRegex(ValueError,'overlap/gap'):terminal_scope([call],worker)

    def test_unexplained_sql_or_multiple_unassigned_calls_fail(self):
        worker=dict(parent_client_process_pid=10,reader_workflows=[dict(end_ns=50)])
        call=dict(origin_request_id=None,sql='SELECT unexpected',send_ns=60,ready_ns=70,role='foreground',client_process_pid=10)
        with self.assertRaisesRegex(ValueError,'overlap/gap'):terminal_scope([call],worker)
        with self.assertRaisesRegex(ValueError,'count'):terminal_scope([call,call],worker)


if __name__=='__main__':unittest.main()
