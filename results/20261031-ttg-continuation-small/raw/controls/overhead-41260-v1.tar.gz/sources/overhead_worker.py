"""SQL-only repeated clean/reference/direct controls; no application workloads."""
import argparse
import json
import os
from pathlib import Path
import statistics
import time
import jaclang
from jaclang.data import pgwire
from jaclang.data.pgwire import PgWireConnection
import continuation_probe as probe
from worker_clock import interpreter_state


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port',type=int,required=True);parser.add_argument('--database',required=True)
    parser.add_argument('--mode',choices=('clean','reference','direct'),required=True)
    parser.add_argument('--repeat',type=int,required=True);parser.add_argument('--iterations',type=int,default=200)
    parser.add_argument('--warmup',type=int,default=20);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();results=[]
    text='x'*16384
    cases=[('scalar','SELECT 1',{},[(1,)]),('text16KiB','SELECT :v::text',dict(v=text),[(text,)]),
        ('json16KiB','SELECT :v::jsonb',dict(v={'payload':text}),None),
        ('multirow128','SELECT i, repeat(:v, 64) FROM generate_series(1,128) i',dict(v='x'),[(i,'x'*64) for i in range(1,129)])]
    offset=args.repeat%len(cases);cases=cases[offset:]+cases[:offset]
    connection=PgWireConnection(user='ttgperf',host='127.0.0.1',port=args.port,database=args.database,
        application_name=f'jac:{os.getpid()}:run')
    try:
        for name,sql,params,expected in cases:
            for phase,count in (('excluded_warmup',args.warmup),('measured',args.iterations)):
                origin=f'{name}:{phase}'
                before=len(pgwire._perf_boundary_records) if args.mode=='reference' else 0
                outer=[]
                with probe.request_scope(origin):
                    for _ in range(count):
                        start=time.perf_counter_ns()
                        value=connection.run(sql,**params)
                        end=time.perf_counter_ns();outer.append(end-start)
                        if name=='json16KiB':
                            decoded=json.loads(value[0][0]) if isinstance(value[0][0],str) else value[0][0]
                            assert value and decoded=={'payload':text}
                        else:assert value==expected
                protocol=None
                if args.mode=='reference':
                    raw=pgwire._perf_boundary_records[before:]
                    assert len(raw)==count
                    protocol=[dict(sql=s,send_ns=a,ready_ns=b,protocol_ns=b-a) for s,a,b in raw]
                results.append(dict(workload=name,phase=phase,n=count,outer_call_ns=outer,
                    reference_protocol=protocol,origin_request_id=origin))
    finally:
        connection.close();probe.flush()
    result=dict(passed=True,kind='SQL_only_observer_controls',mode=args.mode,repeat=args.repeat,
        database=args.database,interpreter=interpreter_state(),results=results,
        timing='Outer call includes all observer call overhead; protocol is actual send-to-Z and excludes parameter encoding/SQL packet construction',
        limitation='No fixed subtraction; no app/CPU/server-only latency claim')
    args.output.write_text(json.dumps(result,indent=2)+'\n')


if __name__=='__main__':main()
