"""Corrected prebuilt-packet TWO-clock reference, SQL controls only."""
import argparse
import difflib
import json
from pathlib import Path
import shutil
from boundary_overlay import OWN,PGWIRE,once,imports
from evidence import sha256
from gate import check_tree,require


def transform(source):
    start=source.index('impl PgWireConnection.run(')
    begin=source.index('        sock.sendall(\n',start)
    end=source.index('        oids: list[int]',begin)
    packet=source[begin:end].replace('        sock.sendall(\n','        _ref_packet = (\n',1)
    source=source[:begin]+packet+'''        _ref_send_ns = _ref_clock.perf_counter_ns();
        sock.sendall(_ref_packet);

'''+source[end:]
    begin=source.index('impl PgWireConnection.run(')
    end=source.index('\n\nimpl PgWireConnection.close',begin)
    body=once(source[begin:end],"            if mtype == 'Z' {\n",'''            if mtype == 'Z' {
                _ref_ready_ns = _ref_clock.perf_counter_ns();
                _perf_boundary_records.append((sql, _ref_send_ns, _ref_ready_ns));
''')
    return imports(source[:begin]+body+source[end:],
        'import time as _ref_clock;\nglob _perf_boundary_records: list = [];\n')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--clean-manifest',type=Path,required=True)
    parser.add_argument('--target',type=Path,required=True)
    args=parser.parse_args();base=check_tree(args.clean_manifest)
    target=args.target.resolve()
    require(target.is_relative_to(OWN) and not target.exists(),'New owned reference directory required')
    metadata=target.parent/(target.name+'-manifest')
    require(not metadata.exists(),'New reference metadata required')
    source=Path(base['root']);old=(source/PGWIRE).read_text();new=transform(old)
    shutil.copytree(source,target)
    path=target/PGWIRE;path.chmod(0o644);path.write_text(new)
    metadata.mkdir();patch=metadata/'reference.patch'
    patch.write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),
        fromfile=str(PGWIRE),tofile=str(PGWIRE))))
    manifest=dict(kind='SQL_only_two_clock_reference',root=str(target),
        base_runtime_manifest_sha256=sha256(args.clean_manifest),
        patch=dict(path=str(patch),sha256=sha256(patch)),
        files={str(p.relative_to(target)):sha256(p) for p in sorted(target.rglob('*')) if p.is_file()},
        generator=dict(path=str(Path(__file__).resolve()),sha256=sha256(__file__)),
        definition='Actual prebuilt packet; clock immediately before real sendall and at same run Z branch as primary; list append after Z; no C/D counters or driver-clock/observer callbacks')
    out=metadata/'manifest.json';out.write_text(json.dumps(manifest,indent=2)+'\n')
    check_tree(out);print(out)


if __name__=='__main__':main()
