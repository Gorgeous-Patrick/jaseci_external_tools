"""Offline source-shape and real child-sink propagation, NOT actual SQL evidence."""
import asyncio
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from types import SimpleNamespace
import unittest
from boundary_overlay import pgwire,prefetch,process,imports
from protocol_reference import transform as reference_transform
from gate import OWN

WIRE_SHAPE='''impl PgWireConnection._startup -> None {
        if mtype == 'R' {
        } elif mtype == 'K' {
            continue;
        }
}
impl PgWireConnection.run(sql: str, **params: any) -> list {
    assert not self._closed;
    try {
        sock.sendall(
            _frame('P', b'query') + _frame('S', b'')
        );
        oids: list[int] = [];
        while True {
            if mtype in ('1', '2', '3', 'C', 'n', 's') {
                continue;
            }
            if mtype == 'D' {
            }
            if mtype == 'E' {
            }
            if mtype == 'Z' {
                if err is not None { raise PgWireError(err); }
                return rows;
            }
        }
    } except Exception as e {
        raise;
    }
}

impl PgWireConnection.close -> None { }
'''
PREFETCH_SHAPE='''def dispatch_prefetch {
            thread.start();
            t.start();
        t.start();
}
'''
PROCESS_SHAPE='''glob _CHILD = """child IPC and readiness unchanged""";
obj ProcessReader {
    def init {
            bufsize=1
        self.startup_ms = (perf_counter() - started) * 1000;
    }
    def load(ids: list) -> list {
        with self.lock {
            self.process.stdin.flush();
            line = self.process.stdout.readline();
            return rows;
        }
    }

    def close { native_close(); }
}
'''


class SourceShapeTests(unittest.TestCase):
    def test_reference_has_two_protocol_clocks_and_prebuilt_packet(self):
        out=reference_transform(WIRE_SHAPE)
        self.assertEqual(out.count('_ref_clock.perf_counter_ns()'),2)
        self.assertIn('_ref_send_ns = _ref_clock.perf_counter_ns();\n        sock.sendall(_ref_packet);',out)
        self.assertIn("if mtype == 'Z' {\n                _ref_ready_ns =",out)
        self.assertNotIn('record_boundary',out)

    def test_imports_preserve_leading_jac_module_docstring(self):
        source='"""Module documentation."""\nimport os;\n'
        out=imports(source,'import observer;\n')
        self.assertTrue(out.startswith('"""Module documentation."""\nimport observer;\n'))

    def test_clock_is_immediately_before_actual_sendall_after_packet_construction(self):
        out=pgwire(WIRE_SHAPE)
        self.assertIn('_perf_frame = (',out)
        self.assertIn('_perf_send_ns = _perf_clock.perf_counter_ns();\n        sock.sendall(_perf_frame);',out)
        self.assertNotIn('sock.sendall(\n',out)

    def test_expected_error_z_is_timestamped_before_raise_and_recorded_in_except(self):
        out=pgwire(WIRE_SHAPE)
        self.assertLess(out.index('_perf_ready_ns = _perf_clock'),out.index('if err is not None'))
        self.assertEqual(out.count('_perf_sink.record_boundary('),2)
        self.assertIn('_perf_d_bytes += len(payload);',out)
        self.assertNotIn('_read_message =',out)

    def test_backend_key_only_first_four_bytes_go_to_sink(self):
        out=pgwire(WIRE_SHAPE)
        self.assertIn("_perf_sink.connected(self, struct.unpack('!I', payload[:4])[0])",out)

    def test_natural_close_body_and_ipc_payload_are_unchanged(self):
        out=pgwire(WIRE_SHAPE)
        self.assertEqual(out[out.index('impl PgWireConnection.close'):],WIRE_SHAPE[WIRE_SHAPE.index('impl PgWireConnection.close'):])
        out=process(PROCESS_SHAPE)
        self.assertIn('child IPC and readiness unchanged',out)
        self.assertIn('env=_perf_sink.child_environment()',out)
        self.assertNotIn('.join(',out)
        self.assertIn('response_wait_includes_child_work=True',out)
        self.assertIn('startup_included=True',out)
        self.assertEqual(out[out.index('    def close'):],PROCESS_SHAPE[PROCESS_SHAPE.index('    def close'):])

    def test_background_binding_at_all_sql_worker_launch_sites(self):
        out=prefetch(PREFETCH_SHAPE)
        self.assertEqual(out.count('bind_worker_thread('),3)
        self.assertEqual(out.count('.start();'),3)

    def test_changed_source_anchor_fails_closed(self):
        with self.assertRaisesRegex(ValueError,'source anchor changed'):
            process('changed ProcessReader source')


class ChildSinkTests(unittest.TestCase):
    def test_exec_child_imports_sink_from_pythonpath_without_parent_install(self):
        with tempfile.TemporaryDirectory(dir=OWN,prefix='synthetic-child-') as directory:
            root=Path(directory)
            env={**os.environ,'PYTHONPATH':str(OWN),'PYTHONDONTWRITEBYTECODE':'1',
                'TTG_PERF_DIR':str(root),'TTG_PERF_CELL_ID':'synthetic-cell',
                'TTG_PERF_TRIAL_ID':'synthetic-trial','TTG_PERF_SERVER_GENERATION':'3',
                'TTG_PERF_CLOCK_DOMAIN':'synthetic-host-monotonic',
                'TTG_PERF_POSTGRES_INSTANCE_ID':'synthetic-no-database',
                'TTG_PERF_REQUEST_ID':'original-request','TTG_PERF_PARENT_PID':str(os.getpid()),
                'TTG_PERF_OBSERVER_CHILD':'1'}
            # Fabricated backend/rows, explicitly not a PgWire execution test.
            code='''import os,struct,time
import continuation_probe as p
class Connection:
    database='synthetic-no-database'
    application_name='jac:%d:run'%os.getpid()
c=Connection();p.connected(c,987654)
stamp=time.perf_counter_ns()
packet=b'S'+struct.pack('!I',4)
p.record_boundary(c,'SELECT synthetic','SELECT synthetic',p.binding(),1,stamp,stamp,
    stamp+1,stamp+2,1,1,8,0,1,1,None,packet,True)
print(os.getpid())
'''
            run=subprocess.run([sys.executable,'-B','-c',code],env=env,capture_output=True,text=True,timeout=10)
            self.assertEqual(run.returncode,0,run.stderr)
            child=int(run.stdout.strip());self.assertNotEqual(child,os.getpid())
            path=root/f'server-3-process-{child}.calls.jsonl'
            record=json.loads(path.read_text())
            self.assertEqual(record['client_process_pid'],child)
            self.assertEqual(record['parent_process_pid'],os.getpid())
            self.assertEqual(record['origin_request_id'],'original-request')
            self.assertEqual(record['actual_executor'],'process')
            self.assertEqual(record['cell_id'],'synthetic-cell')
            self.assertEqual(record['backend_pid'],987654)  # synthetic fixture PID
            self.assertNotIn('secret',path.read_text())

    def test_natural_http_close_and_201_response_are_unchanged(self):
        from http_observer import install
        import continuation_probe as probe
        calls=[]
        class App:
            async def dispatch(self,request):
                calls.append(('native_dispatch',probe.binding()[0]))
                return SimpleNamespace(status_code=201,body={'created':True})
        class Context:
            def close(self): calls.append(('native_close',probe.binding()[0]));return 'closed'
        install(App,Context)
        request=SimpleNamespace(headers={'X-TTG-Perf-Request':'synthetic-r1'},url=SimpleNamespace(path='/walker/Run'))
        result=asyncio.run(App().dispatch(request))
        self.assertEqual(result.status_code,201)
        self.assertEqual(calls,[('native_dispatch','synthetic-r1')])
        self.assertEqual(Context().close(),'closed')
        self.assertEqual(calls[-1],('native_close',None))


if __name__=='__main__': unittest.main()
