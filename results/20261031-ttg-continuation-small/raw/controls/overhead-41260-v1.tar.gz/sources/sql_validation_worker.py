"""Dedicated synthetic SQL/reader controls, never application samples.

Run only in the coordinated database window against an immutable overlay.
Parent response wait includes child DB work; it is never called pure IPC time.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import threading
import time
from uuid import UUID
import jaclang
from jaclang.data.pgwire import PgWireConnection,PgWireError
from jaclang.data.store import PgStore,ConnInfo,AnchorRow
from jaclang.runtime.ttg_process_reader import ProcessReader
import continuation_probe as probe


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port',type=int,required=True)
    parser.add_argument('--database',required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();checks=[];concurrency=[];json_evidence=None
    connection=PgWireConnection(user='ttgperf',host='127.0.0.1',port=args.port,database=args.database,
        application_name=f'jac:{os.getpid()}:run')
    try:
        with probe.request_scope('sql-controls'):
            assert connection.run("SELECT count(*) FROM pg_tables WHERE schemaname='public'")==[(0,)]
            checks.append('initial_database_public_schema_empty')
            assert connection.run('SELECT 1')==[(1,)]
            text='x'*16384
            assert connection.run('SELECT :payload::text',payload=text)==[(text,)]
            returned=connection.run('SELECT :payload::jsonb',payload={'payload':text})
            assert len(returned)==1 and len(returned[0])==1
            raw_json=returned[0][0]
            parsed=json.loads(raw_json) if isinstance(raw_json,str) else raw_json
            assert isinstance(parsed,dict) and parsed=={'payload':text}
            json_evidence=dict(native_type=type(raw_json).__name__,parsed_type=type(parsed).__name__,
                canonical_content_sha256=hashlib.sha256(json.dumps(parsed,sort_keys=True,separators=(',',':')).encode()).hexdigest(),
                string_decoded=isinstance(raw_json,str))
            rows=connection.run('SELECT i, repeat(:payload, 4) FROM generate_series(1,128) i',payload='a')
            assert rows==[(i,'aaaa') for i in range(1,129)]
            checks.extend(['scalar','16KiB_text','16KiB_json','multirow128'])
            for sql in ('SELECT FROM','SELECT 1/0'):
                try: connection.run(sql)
                except PgWireError: checks.append('expected_pg_error:'+sql)
                else: raise AssertionError('Expected PostgreSQL error missing')
            marker=object()
            coerced=connection.run('SELECT :value',value={'not_json':marker})
            assert json.loads(coerced[0][0])=={'not_json':str(marker)}
            checks.append('unsupported_JSON_objects_intentionally_stringified')
            try: connection.run('SELECT :value',value=chr(0xD800))
            except UnicodeEncodeError: checks.append('unicode_encoding_error_before_send')
            else: raise AssertionError('Expected parameter-encoding error missing')
        closed=PgWireConnection(user='ttgperf',host='127.0.0.1',port=args.port,database=args.database,
            application_name=f'jac:{os.getpid()}:run')
        closed.close()
        try: closed.run('SELECT 1')
        except AssertionError as error:
            assert str(error)=='connection is closed'
            checks.append('native_closed_assert_before_rows_initialization_no_undefined_sink_local')
        else: raise AssertionError('Native closed-connection guard disappeared')
        info=ConnInfo(host='127.0.0.1',port=args.port,user='ttgperf',database=args.database)
        store=PgStore(conninfo=info,auto_schema=False,pending_reset=False)
        ids=[UUID(int=1000+i) for i in range(32)]
        with probe.request_scope('synthetic-fixture'):
            store.ensure_schema({})
            store.upsert([AnchorRow(id=uid,kind='NodeAnchor',arch_type='SyntheticPayload',
                arch_module='sql_validation_worker',props={'ordinal':i,'payload':'y'*16384})
                for i,uid in enumerate(ids)])
            store.commit()
        try:
            for mode in ('thread','process'):
                with probe.request_scope('reader-'+mode):
                    begin=time.perf_counter_ns()
                    reader=ProcessReader(store) if mode=='process' else store.reader_clone()
                    ready=time.perf_counter_ns()
                    child=reader.process.pid if mode=='process' else None
                    try:
                        for batch in range(3):
                            outputs=[];errors=[]
                            def load():
                                try:
                                    result=reader.load(ids) if mode=='process' else list(reader.load_full(ids).values())
                                    outputs.extend(result)
                                except Exception as error: errors.append(f'{type(error).__name__}: {error}')
                            worker=threading.Thread(target=load)
                            probe.bind_worker_thread(worker,'ipc_parent_thread' if mode=='process' else 'thread')
                            worker.start()
                            # Deliberate server sleep ONLY to validate interval overlap.
                            # It is not network latency injection or an app workload.
                            connection.run('SELECT pg_sleep(0.05)')
                            worker.join(timeout=20)
                            assert not worker.is_alive() and not errors,errors
                            assert {row.id for row in outputs}==set(ids)
                            assert all(row.props['payload']=='y'*16384 for row in outputs)
                            assert {row.props['ordinal'] for row in outputs}==set(range(32))
                    finally: reader.close()
                    end=time.perf_counter_ns()
                    if child:
                        try:os.kill(child,0)
                        except ProcessLookupError:pass
                        else:raise AssertionError('Child survived native reader close')
                    concurrency.append(dict(executor=mode,start_ns=begin,ready_ns=ready,end_ns=end,
                        child_process_pid=child,batches=3,expected_rows_per_batch=32,
                        startup_included=True,delay='Explicit synthetic SELECT pg_sleep(0.05)',passed=True))
        finally: store.close()
        checks.append('actual_native_thread_and_ProcessReader_payload_integrity')
    finally:
        connection.close()
        probe.flush()
    result=dict(passed=True,kind='synthetic_SQL_and_native_reader_validation',benchmark_execution=False,
        database=args.database,parent_client_process_pid=os.getpid(),checks=checks,reader_workflows=concurrency,
        jsonb_return_contract=json_evidence,
        precondition_failure_scope='Closed-connection assertion occurs before native inner try; it sends no SQL and is validated separately from protocol-call totals')
    args.output.write_text(json.dumps(result,indent=2)+'\n')


if __name__=='__main__':main()
