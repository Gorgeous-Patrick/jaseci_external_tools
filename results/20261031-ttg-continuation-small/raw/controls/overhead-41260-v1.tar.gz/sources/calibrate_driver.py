"""Rotated SQL-only controls, same stopped owned cluster/DB as validated reader."""
import argparse
from datetime import datetime,timezone
import json
from pathlib import Path
import statistics
import subprocess
from boundary_overlay import OWN
from evidence import sha256,read_json,verify_case
from gate import check_tree
from owned_postgres import OwnedPostgres,runtime_env
from reconcile_sql_validation import validate as validate_capture
from validate_preparation import EVIDENCE


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for key in ('clean-manifest','reference-manifest','direct-manifest','validated-capture','cluster','output'):
        parser.add_argument('--'+key,type=Path,required=True)
    parser.add_argument('--repeats',type=int,default=9);parser.add_argument('--iterations',type=int,default=200)
    args=parser.parse_args();output=args.output.resolve()
    if not output.is_relative_to(EVIDENCE) or output==EVIDENCE:raise ValueError('New owned output required')
    output.mkdir(parents=True,exist_ok=False)
    manifests={name:getattr(args,name+'_manifest') for name in ('clean','reference','direct')}
    source={name:Path(check_tree(path)['root']) for name,path in manifests.items()}
    proof=validate_capture(args.validated_capture)
    previous=read_json(args.validated_capture/'summary.json')
    if previous['clean_manifest']['sha256']!=sha256(args.clean_manifest) or previous['overlay_manifest']['sha256']!=sha256(args.direct_manifest):
        raise ValueError('Controls must use exactly validated clean/direct source')
    sources={str(p):sha256(p) for p in OWN.glob('*.py')}
    (output/'sources').mkdir()
    import shutil
    for path in [*OWN.glob('*.py'),OWN/'runtime.sh']:shutil.copy2(path,output/'sources'/path.name)
    samples=[];error=None;started=datetime.now(timezone.utc).isoformat()
    with OwnedPostgres(args.cluster,source['clean'],statement_logging=False,
            resume_owner=previous['cluster_owner'],resume_database=previous['database']) as postgres:
        # Explicit server setting change is for this separate diagnostic only.
        postgres.sql("ALTER SYSTEM SET log_statement='none'")
        postgres.sql('SELECT pg_reload_conf()')
        if postgres.sql('SHOW log_statement')!='none':raise ValueError('SQL logging not disabled for controls')
        try:
            modes=['clean','reference','direct']
            for repeat in range(args.repeats):
                order=modes[repeat%3:]+modes[:repeat%3]
                for mode in order:
                    directory=output/f'r{repeat:02d}-{mode}';directory.mkdir()
                    env=runtime_env(source[mode],source[mode].name)
                    if mode=='direct':env.update(TTG_PERF_DIR=str(directory),TTG_PERF_CELL_ID='SQL-only-overhead',
                        TTG_PERF_TRIAL_ID=directory.name,TTG_PERF_SERVER_GENERATION='1',
                        TTG_PERF_CLOCK_DOMAIN='same-host-perf_counter_ns',TTG_PERF_POSTGRES_INSTANCE_ID=postgres.owner)
                    command=['bash',str(OWN/'runtime.sh'),str(OWN/'overhead_worker.py'),
                        '--port',str(postgres.port),'--database',previous['database'],'--mode',mode,
                        '--repeat',str(repeat),'--iterations',str(args.iterations),'--output',str(directory/'result.json')]
                    with (directory/'stdout.txt').open('w') as stdout,(directory/'stderr.txt').open('w') as stderr:
                        process=subprocess.Popen(command,env=env,stdout=stdout,stderr=stderr)
                        postgres.services.append(process);code=process.wait(timeout=180)
                    if code:raise RuntimeError(f'Control failed: {directory}, exit{code}')
                    result=read_json(directory/'result.json')
                    direct=[]
                    if mode=='direct':
                        direct=[json.loads(line) for p in directory.glob('server-*.calls.jsonl') for line in p.read_text().splitlines()]
                    for block in result['results']:
                        protocols=None
                        if mode=='reference':protocols=[r['protocol_ns'] for r in block['reference_protocol']]
                        if mode=='direct':
                            raw=[r for r in direct if r['origin_request_id']==block['origin_request_id']]
                            if len(raw)!=block['n'] or any(r['command_complete']!=1 or r['ready_messages']!=1 or r['error'] for r in raw):
                                raise ValueError('Control execution/count mismatch')
                            protocols=[r['ready_ns']-r['send_ns'] for r in raw]
                        samples.append(dict(mode=mode,repeat=repeat,workload=block['workload'],phase=block['phase'],
                            n=block['n'],outer_median_ns=statistics.median(block['outer_call_ns']),
                            protocol_median_ns=statistics.median(protocols) if protocols else None,
                            result_path=str(directory/'result.json'),result_sha256=sha256(directory/'result.json')))
                    print(json.dumps(dict(completed=directory.name)),flush=True)
            for path in manifests.values():check_tree(path)
            if sources!={str(p):sha256(p) for p in OWN.glob('*.py')}:raise ValueError('Control source mutation')
        except Exception as failure:error=f'{type(failure).__name__}: {failure}'
        summary=dict(passed=error is None,kind='SQL_only_rotated_overhead_controls',formal_samples=0,
            started_utc=started,completed_utc=datetime.now(timezone.utc).isoformat(),error=error,
            repeats=args.repeats,iterations_per_measured_block=args.iterations,excluded_warmup_calls_per_block=20,
            policy_order='clean/reference/direct rotated by repeat modulo3',SQL_logging='none',
            manifests={k:dict(path=str(v.resolve()),sha256=sha256(v)) for k,v in manifests.items()},
            validated_capture=proof['input_seal'],sources_before=sources,
            sources_after={str(p):sha256(p) for p in OWN.glob('*.py')},samples=samples,
            interpretation='Observed repeated controls and variation; no exact-overhead inference, subtraction or application performance conclusion')
        (output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
        (output/'artifacts.json').write_text(json.dumps(dict(passed=summary['passed'],files={
            str(p.relative_to(output)):sha256(p) for p in output.rglob('*') if p.is_file()}),indent=2)+'\n')
        if summary['passed']:postgres.drop_completed_database(previous['database'],output/'artifacts.json')
    print(json.dumps(dict(output=str(output),passed=summary['passed'],error=error)))
    return 0 if summary['passed'] else 1


if __name__=='__main__':raise SystemExit(main())
