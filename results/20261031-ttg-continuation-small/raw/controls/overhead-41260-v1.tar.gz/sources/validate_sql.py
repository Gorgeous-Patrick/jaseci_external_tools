"""One-cluster synthetic overlay validation; formal application gate stays closed."""
import argparse
import csv
from datetime import datetime,timezone
import json
import os
from pathlib import Path
import shutil
import subprocess
import time
from boundary_overlay import OWN
from evidence import read_json,sha256,verify_case
from gate import check_tree
from intervals import concurrency,executor_evidence
from owned_postgres import OwnedPostgres,runtime_env
from sql_reconciliation import reconcile
from validate_preparation import EVIDENCE


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--clean-manifest',type=Path,required=True)
    parser.add_argument('--overlay-manifest',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--cluster',type=Path,required=True)
    parser.add_argument('--resume-summary',type=Path)
    args=parser.parse_args();output=args.output.resolve()
    if not output.is_relative_to(EVIDENCE) or output==EVIDENCE:raise ValueError('New owned evidence path required')
    output.mkdir(parents=True,exist_ok=False)
    clean=check_tree(args.clean_manifest);overlay=check_tree(args.overlay_manifest)
    if overlay['base_runtime_manifest_sha256']!=sha256(args.clean_manifest):raise ValueError('Overlay base mismatch')
    before={str(p):sha256(p) for p in OWN.glob('*.py')}
    (output/'sources').mkdir()
    for source in [*OWN.glob('*.py'),OWN/'runtime.sh']:
        shutil.copy2(source,output/'sources'/source.name)
    started=datetime.now(timezone.utc).isoformat();passed=False;error=None
    resume={}
    if args.resume_summary:
        verify_case(args.resume_summary.parent,required=(args.resume_summary.name,),allow_failed=True)
        previous=read_json(args.resume_summary)
        if previous['passed'] or previous['clean_manifest']['sha256']!=sha256(args.clean_manifest) or previous['overlay_manifest']['sha256']!=sha256(args.overlay_manifest):
            raise ValueError('Resume requires exact predecessor failed synthetic source evidence')
        resume=dict(resume_owner=previous['cluster_owner'],resume_database=previous['database'])
    with OwnedPostgres(args.cluster,Path(clean['root']),statement_logging=True,**resume) as postgres:
        database=resume['resume_database'] if resume else postgres.create_database()
        environment=runtime_env(Path(overlay['root']),Path(overlay['root']).name)
        environment.update(TTG_PERF_DIR=str(output),TTG_PERF_CELL_ID='synthetic-sql-reader-control',
            TTG_PERF_TRIAL_ID=output.name,TTG_PERF_SERVER_GENERATION='1',
            TTG_PERF_CLOCK_DOMAIN='same-host-perf_counter_ns',TTG_PERF_POSTGRES_INSTANCE_ID=postgres.owner)
        command=['bash',str(OWN/'runtime.sh'),str(OWN/'sql_validation_worker.py'),
            '--port',str(postgres.port),'--database',database,'--output',str(output/'worker-result.json')]
        try:
            with (output/'worker.stdout.txt').open('w') as stdout,(output/'worker.stderr.txt').open('w') as stderr:
                service=subprocess.Popen(command,env=environment,stdout=stdout,stderr=stderr)
                postgres.services.append(service)
                returncode=service.wait(timeout=240)
            if returncode:raise RuntimeError(f'Synthetic SQL worker exited{returncode}; see worker.stderr.txt')
            # Natural worker/children have exited before any sealing. Stop the
            # owned collector so its CSV bytes are complete and stable.
            postgres.stop()
            for i,path in enumerate(postgres.current_csv()):
                shutil.copy2(path,output/f'postgres-{i}.csv')
            calls=[];connections={}
            for path in sorted(output.glob('server-*.calls.jsonl')):
                calls.extend(json.loads(line) for line in path.read_text().splitlines() if line)
            for path in sorted(output.glob('server-*.events.jsonl')):
                for line in path.read_text().splitlines():
                    event=json.loads(line)
                    if event['kind']=='connection':
                        value={key:event[key] for key in ('database','client_process_pid','application_name')}
                        pid=event['backend_pid']
                        if pid in connections and connections[pid]!=value:raise ValueError('Reused ambiguous backend identity')
                        connections[pid]=value
            csv_rows=[]
            for path in sorted(output.glob('postgres-*.csv')):
                with path.open(newline='') as file:csv_rows.extend(csv.reader(file))
            encoding_failures=[c for c in calls if c.get('error') and c['error'].startswith('UnicodeEncodeError:')]
            if len(encoding_failures)!=1:raise ValueError('Missing exact pre-send UnicodeEncodeError evidence')
            failure=encoding_failures[0]
            if failure['send_ns'] is not None or failure['ready_ns'] is not None or any(
                    failure[key] for key in ('command_complete','data_rows','error_messages','ready_messages')):
                raise ValueError('Pre-send failure incorrectly dispatched or counted SQL')
            reconciled=reconcile(calls,csv_rows,database,connections,
                allowed_jac_commands=('run','-c','sql_validation_worker.py'))
            (output/'sql-reconciliation.json').write_text(json.dumps(reconciled,indent=2)+'\n')
            overlaps=concurrency(calls)
            for mode in ('thread','process'):
                relevant=[c for c in calls if c['origin_request_id']=='reader-'+mode]
                execution=executor_evidence(relevant,mode,read_json(output/'worker-result.json')['parent_client_process_pid'])
                if not execution['sql_execution_observed']:raise ValueError('No actual '+mode+' background SQL')
                rows=[r for r in overlaps['requests'] if r['origin_request_id']=='reader-'+mode]
                if not rows or not all(r['distinct_backend_overlap_ns']>0 for r in rows):raise ValueError('No actual distinct-backend overlap')
                if mode=='process' and not all(r['separate_process_distinct_backend_overlap_ns']>0 for r in rows):
                    raise ValueError('No actual child-process SQL overlap')
            (output/'concurrency.json').write_text(json.dumps(overlaps,indent=2)+'\n')
            check_tree(args.clean_manifest);check_tree(args.overlay_manifest)
            if before!={str(p):sha256(p) for p in OWN.glob('*.py')}:raise ValueError('Harness changed during synthetic validation')
            passed=True
        except Exception as failure:
            error=f'{type(failure).__name__}: {failure}'
            for service in postgres.services:
                if service.poll() is None:
                    service.terminate()
                    try:service.wait(timeout=20)
                    except subprocess.TimeoutExpired:service.kill();service.wait(timeout=10)
            postgres.stop()
            for i,path in enumerate(postgres.current_csv()):
                shutil.copy2(path,output/f'postgres-{i}.csv')
        summary=dict(kind='synthetic_SQL_boundary_child_validation',passed=passed,formal_samples=0,
            started_utc=started,completed_utc=datetime.now(timezone.utc).isoformat(),error=error,
            command=command,database=database,cluster_owner=postgres.owner,
            resumed_failed_evidence=dict(path=str(args.resume_summary),sha256=sha256(args.resume_summary)) if args.resume_summary else None,
            prior_csv_excluded_from_this_server_generation=postgres.csv_before_start,
            sources_before=before,sources_after={str(p):sha256(p) for p in OWN.glob('*.py')},
            clean_manifest=dict(path=str(args.clean_manifest.resolve()),sha256=sha256(args.clean_manifest)),
            overlay_manifest=dict(path=str(args.overlay_manifest.resolve()),sha256=sha256(args.overlay_manifest)),
            limitation='SQL-only transport/count/concurrency control; no app correctness, performance, model-benefit or overhead acceptance implied')
        (output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
        (output/'artifacts.json').write_text(json.dumps(dict(passed=passed,files={
            str(p.relative_to(output)):sha256(p) for p in output.rglob('*') if p.is_file()}),indent=2)+'\n')
        if passed:
            verify_case(output)
            postgres.start()
            postgres.drop_completed_database(database,output/'artifacts.json')
        # Failed database retained; __exit__ stops services/cluster naturally.
    print(json.dumps(dict(output=str(output),passed=passed,error=error)))
    return 0 if passed else 1


if __name__=='__main__':raise SystemExit(main())
