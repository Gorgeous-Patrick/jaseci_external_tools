"""NEW supplemental checker for preserved v3 CSV-limit failure; no SQL rerun."""
import argparse
import csv
from contextlib import contextmanager
import json
from pathlib import Path
from evidence import read_json,sha256,verify_case
from intervals import concurrency,executor_evidence
from sql_reconciliation import reconcile
from validate_preparation import EVIDENCE,OWN


@contextmanager
def csv_limit(limit=64*1024*1024):
    previous=csv.field_size_limit()
    try:
        csv.field_size_limit(limit);yield
    finally:csv.field_size_limit(previous)


def terminal_scope(calls,worker):
    """Prove the one synthetic finally:store.close DISCARD; never call startup."""
    unassigned=[c for c in calls if not c.get('origin_request_id') and c.get('send_ns') is not None]
    if len(unassigned)!=1:raise ValueError('Unexpected unassigned SQL count')
    call=unassigned[0]
    last=max(r['end_ns'] for r in worker['reader_workflows'])
    if call['sql']!='DISCARD ALL' or call['role']!='foreground' or call['client_process_pid']!=worker['parent_client_process_pid'] or call['send_ns']<last:
        raise ValueError('Unexplained unassigned SQL overlap/gap')
    return dict(classification='synthetic_post_reader_final_store_close_control',
        sql=call['sql'],send_ns=call['send_ns'],ready_ns=call['ready_ns'],
        after_last_reader_end_ns=last,retained_in_all_SQL_counts=True,
        native_origin_request_id=None,source='sql_validation_worker.py finally: store.close()')


def validate(directory):
    directory=Path(directory).resolve()
    consumed=[directory/'summary.json',directory/'worker-result.json',
        *directory.glob('server-*.calls.jsonl'),*directory.glob('server-*.events.jsonl'),
        *directory.glob('postgres-*.csv')]
    seal=verify_case(directory,required=[str(p.relative_to(directory)) for p in consumed],allow_failed=True)
    original=read_json(directory/'summary.json');worker=read_json(directory/'worker-result.json')
    if original.get('passed') is not False or original.get('error')!='Error: field larger than field limit (131072)':
        raise ValueError('This supplemental checker requires the explicit preserved CSV-limit failure')
    if worker.get('passed') is not True or worker.get('benchmark_execution') is not False:
        raise ValueError('Synthetic worker did not pass')
    if {r['executor'] for r in worker['reader_workflows']}!={'thread','process'} or not all(
            r['passed'] and r['batches']==3 and r['expected_rows_per_batch']==32 for r in worker['reader_workflows']):
        raise ValueError('Reader coverage/integrity incomplete')
    calls=[json.loads(line) for p in directory.glob('server-*.calls.jsonl') for line in p.read_text().splitlines() if line]
    events=[json.loads(line) for p in directory.glob('server-*.events.jsonl') for line in p.read_text().splitlines() if line]
    connections={}
    for event in events:
        if event['kind']!='connection':continue
        value={key:event[key] for key in ('database','client_process_pid','application_name')}
        pid=event['backend_pid']
        if pid in connections and connections[pid]!=value:raise ValueError('Ambiguous actual backend identity')
        connections[pid]=value
    unassigned=terminal_scope(calls,worker)
    with csv_limit():
        rows=[]
        for path in directory.glob('postgres-*.csv'):
            with path.open(newline='') as file:rows.extend(csv.reader(file))
    sql=reconcile(calls,rows,worker['database'],connections,
        allowed_jac_commands=('run','-c','sql_validation_worker.py'))
    encoding=[c for c in calls if c.get('error') and c['error'].startswith('UnicodeEncodeError:')]
    if len(encoding)!=1:raise ValueError('Missing encoding-failure control')
    failed=encoding[0]
    if failed['send_ns'] is not None or failed['ready_ns'] is not None or any(failed[k] for k in
            ('command_complete','data_rows','error_messages','ready_messages')):
        raise ValueError('Pre-send error dispatched SQL')
    overlaps=concurrency([c for c in calls if c.get('origin_request_id')])
    executors={}
    for mode in ('thread','process'):
        relevant=[c for c in calls if c['origin_request_id']=='reader-'+mode]
        proof=executor_evidence(relevant,mode,worker['parent_client_process_pid'])
        if not proof['sql_execution_observed']:raise ValueError('No actual '+mode+' SQL')
        scoped=[r for r in overlaps['requests'] if r['origin_request_id']=='reader-'+mode]
        if len(scoped)!=1 or scoped[0]['distinct_backend_overlap_ns']<=0:raise ValueError('Missing real backend overlap')
        if mode=='process' and scoped[0]['separate_process_distinct_backend_overlap_ns']<=0:
            raise ValueError('Missing actual child SQL overlap')
        executors[mode]=proof
    # Recheck every raw byte after reading; original failed seal stays unchanged.
    if verify_case(directory,allow_failed=True)!=seal:raise ValueError('Input seal changed')
    return dict(passed=True,kind='supplemental_SQL_transport_validation',formal_samples=0,
        input_seal=seal,original_failed_summary=dict(path=str(directory/'summary.json'),sha256=sha256(directory/'summary.json')),
        original_checker_failure=original['error'],csv_field_limit=64*1024*1024,
        sql=sql,concurrency=overlaps,executor_evidence=executors,terminal_unassigned_scope=unassigned,
        pre_send_failures=1,worker_result=worker,
        distinction='Synthetic actual SQL/transport/reader integrity only; no app performance or exact overhead conclusion')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();output=args.output.resolve()
    if not output.is_relative_to(EVIDENCE) or output==EVIDENCE:raise ValueError('New owned output required')
    output.mkdir(parents=True,exist_ok=False)
    result=validate(args.input)
    sources={str(OWN/name):sha256(OWN/name) for name in
        ('reconcile_sql_validation.py','sql_reconciliation.py','evidence.py','intervals.py')}
    result['checker_sources']=sources
    (output/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    (output/'artifacts.json').write_text(json.dumps(dict(passed=True,files={'result.json':sha256(output/'result.json')}),indent=2)+'\n')
    print(json.dumps(dict(output=str(output),passed=True,totals=result['sql']['totals'],executors=result['executor_evidence'])))


if __name__=='__main__':main()
