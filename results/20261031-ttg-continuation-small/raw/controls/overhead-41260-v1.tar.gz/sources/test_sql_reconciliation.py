"""Fabricated CSV/driver controls only: no server or runtime execution."""
import unittest
from sql_reconciliation import canonical_sql, fingerprint, reconcile


def csvrow(sql,line=1,error=False,label='jac:100:run',pid=200,execute=True):
    row=['']*26
    row[2]='owned_synthetic';row[3]=str(pid);row[6]=str(line);row[22]=label
    row[11]='ERROR' if error else 'LOG'
    row[13]='deliberate parse error' if error else 'execute <unnamed>: '+sql
    row[19]=sql if error else ''
    return row


def call(sql='SELECT $1',failed=False):
    return dict(sql=sql,backend_pid=200,client_process_pid=100,database='owned_synthetic',
        send_ns=1,ready_ns=2,ready_messages=1,command_complete=0 if failed else 1,
        error_messages=1 if failed else 0,protocol_mode='extended_single_statement')


class ReconciliationTests(unittest.TestCase):
    def compare(self,calls,rows):
        return reconcile(calls,rows,'owned_synthetic',{
            200:dict(database='owned_synthetic',client_process_pid=100,application_name='jac:100:run')})

    def test_success_and_control_sql(self):
        calls=[call(),dict(call('COMMIT'),send_ns=3,ready_ns=4)]
        result=self.compare(calls,[csvrow('SELECT $1'),csvrow('COMMIT',line=2)])
        self.assertEqual(result['totals'],dict(driver_dispatch=2,server_execute=2,server_error=0,data_dispatch=1,control_dispatch=1))

    def test_parse_error_without_execute(self):
        r=self.compare([call('BAD',True)],[csvrow('BAD',error=True)])
        self.assertEqual((r['totals']['server_execute'],r['totals']['server_error']),(0,1))

    def test_execution_error_after_execute_is_not_double_counted(self):
        r=self.compare([call('SELECT 1/0',True)],[csvrow('SELECT 1/0'),csvrow('SELECT 1/0',line=2,error=True)])
        self.assertEqual((r['totals']['driver_dispatch'],r['totals']['server_execute'],r['totals']['server_error']),(1,1,1))

    def test_server_extras_fail(self):
        with self.assertRaisesRegex(ValueError,'extras'):
            self.compare([call()],[csvrow('SELECT $1'),csvrow('SELECT 2',line=2)])

    def test_unknown_pid_fails(self):
        with self.assertRaisesRegex(ValueError,'unexpected owned-DB backend'):
            self.compare([call()],[csvrow('SELECT $1',pid=201)])

    def test_old_exact_label_is_rejected(self):
        with self.assertRaisesRegex(ValueError,'application label'):
            self.compare([call()],[csvrow('SELECT $1',label='jac')])

    def test_actual_child_c_label_is_allowed_only_with_exact_pid_and_connection(self):
        connections={200:dict(database='owned_synthetic',client_process_pid=100,application_name='jac:100:-c')}
        self.assertTrue(reconcile([call()],[csvrow('SELECT $1',label='jac:100:-c')],
            'owned_synthetic',connections)['passed'])
        connections[200]['application_name']='jac:101:-c'
        with self.assertRaisesRegex(ValueError,'application label'):
            reconcile([call()],[csvrow('SELECT $1',label='jac:101:-c')],'owned_synthetic',connections)

    def test_sql_changed_literal_fails(self):
        with self.assertRaisesRegex(ValueError,'SQL or order mismatch'):
            self.compare([call("SELECT 'unchanged'")],[csvrow("SELECT 'changed'")])

    def test_error_not_in_driver_fails(self):
        with self.assertRaisesRegex(ValueError,'extras'):
            self.compare([call()],[csvrow('SELECT $1'),csvrow('SELECT $1',line=2,error=True)])

    def test_expected_error_must_exist_on_server(self):
        with self.assertRaisesRegex(ValueError,'matching server error'):
            self.compare([call(failed=True)],[csvrow('SELECT $1')])

    def test_whitespace_only_outside_quoted_content(self):
        self.assertEqual(canonical_sql(" SELECT  'a  b'  ,  \"c  d\"  "),"SELECT 'a  b' , \"c  d\"")
        self.assertNotEqual(fingerprint("SELECT 'a  b'"),fingerprint("SELECT 'a b'"))
        self.assertNotEqual(fingerprint('SELECT $$a  b$$'),fingerprint('SELECT $$a b$$'))
        self.assertEqual(canonical_sql(' SELECT  $tag$a  b$tag$ '),'SELECT $tag$a  b$tag$')

    def test_quotes_and_comments_are_preserved(self):
        self.assertEqual(canonical_sql("SELECT 'a''  b'"),"SELECT 'a''  b'")
        self.assertEqual(canonical_sql('SELECT /* a  b /*nested*/ */ 1'),'SELECT /* a  b /*nested*/ */ 1')
        self.assertNotEqual(fingerprint('SELECT 1 --a  b\n'),fingerprint('SELECT 1 --a b\n'))

    def test_unterminated_quote_fails_closed(self):
        with self.assertRaisesRegex(ValueError,'Unterminated'): canonical_sql("SELECT 'broken")


if __name__=='__main__': unittest.main()
