"""Read-only source-transform audit; does not snapshot, import or run runtime."""
import argparse
from datetime import datetime,timezone
import json
from pathlib import Path
from boundary_overlay import PGWIRE,PREFETCH,PROCESS,pgwire,prefetch,process,OWN
from evidence import sha256
from validate_preparation import EVIDENCE


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    output=args.output.resolve()
    if not output.is_relative_to(EVIDENCE) or output==EVIDENCE:
        raise ValueError('Evidence output must be a new owned directory')
    output.mkdir(parents=True,exist_ok=False)
    transforms=((PGWIRE,pgwire),(PREFETCH,prefetch),(PROCESS,process))
    before={str(r):sha256(args.source/r) for r,_ in transforms}
    rows=[]
    for relative,transform in transforms:
        try:
            result=transform((args.source/relative).read_text())
            rows.append(dict(path=str(relative),text_transform_passed=True,
                generated_characters=len(result)))
        except Exception as error:
            rows.append(dict(path=str(relative),text_transform_passed=False,error=str(error)))
    after={str(r):sha256(args.source/r) for r,_ in transforms}
    summary=dict(kind='read_only_text_instrumentability',timestamp_utc=datetime.now(timezone.utc).isoformat(),
        runtime_source=str(args.source.resolve()),runtime_executed=False,runtime_snapshot_created=False,
        runtime_compilation=False,database_execution=False,passed=before==after and all(r['text_transform_passed'] for r in rows),
        sources_before=before,sources_after=after,results=rows,
        generator_sha256=sha256(OWN/'boundary_overlay.py'),observer_sha256=sha256(OWN/'continuation_probe.py'),
        limitation='Text anchors only; no final-runtime syntax, transport, actual child SQL, counts or overhead validation claimed')
    (output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    (output/'artifacts.json').write_text(json.dumps(dict(passed=summary['passed'],files={
        'summary.json':sha256(output/'summary.json')}),indent=2)+'\n')
    print(json.dumps(summary,indent=2))
    return 0 if summary['passed'] else 1


if __name__=='__main__': raise SystemExit(main())
