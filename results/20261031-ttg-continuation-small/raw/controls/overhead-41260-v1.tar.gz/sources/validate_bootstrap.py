"""Compile/import candidate overlay with raw logs; no database/application."""
import argparse
from datetime import datetime,timezone
import json
import os
from pathlib import Path
import subprocess
from boundary_overlay import OWN
from gate import check_tree
from evidence import sha256,read_json
from validate_preparation import EVIDENCE


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--runtime-manifest',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();output=args.output.resolve()
    if not output.is_relative_to(EVIDENCE) or output==EVIDENCE:
        raise ValueError('New owned evidence output required')
    output.mkdir(parents=True,exist_ok=False)
    manifest=check_tree(args.runtime_manifest)
    source=Path(manifest['root'])
    environment={**os.environ,'TTG_RUNTIME_SOURCE':str(source),
        'TTG_RUNTIME_CACHE':str(OWN/('cache-'+source.name+'-runtime')),
        'TTG_CACHE_DIR':str(OWN/('cache-'+source.name+'-compiler'))}
    # No benchmark entrypoints, SQL, sessions or services are invoked.
    code='import jaclang; from jaclang.data.pgwire import PgWireConnection; from jaclang.runtime.ttg_process_reader import ProcessReader; from jaclang.runtime.prefetch import dispatch_prefetch; print("CONTINUATION_OVERLAY_BOOTSTRAP_OK")'
    command=['bash',str(OWN/'runtime.sh'),'-c',code]
    started=datetime.now(timezone.utc).isoformat()
    with (output/'stdout.txt').open('w') as stdout,(output/'stderr.txt').open('w') as stderr:
        result=subprocess.run(command,env=environment,stdout=stdout,stderr=stderr)
    check_tree(args.runtime_manifest)
    summary=dict(kind='runtime_overlay_bootstrap',benchmark_execution=False,database_execution=False,
        command=command,environment={key:environment[key] for key in ('TTG_RUNTIME_SOURCE','TTG_RUNTIME_CACHE','TTG_CACHE_DIR')},
        started_utc=started,completed_utc=datetime.now(timezone.utc).isoformat(),returncode=result.returncode,
        runtime_manifest=dict(path=str(args.runtime_manifest.resolve()),sha256=sha256(args.runtime_manifest)),
        sources={p.name:sha256(p) for p in (OWN/'boundary_overlay.py',OWN/'continuation_probe.py',OWN/'runtime.sh',Path(__file__))},
        passed=result.returncode==0)
    (output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    (output/'artifacts.json').write_text(json.dumps(dict(passed=summary['passed'],files={
        p.name:sha256(p) for p in output.iterdir() if p.is_file()}),indent=2)+'\n')
    print(json.dumps(dict(output=str(output),passed=summary['passed'],returncode=result.returncode)))
    return result.returncode


if __name__=='__main__': raise SystemExit(main())
